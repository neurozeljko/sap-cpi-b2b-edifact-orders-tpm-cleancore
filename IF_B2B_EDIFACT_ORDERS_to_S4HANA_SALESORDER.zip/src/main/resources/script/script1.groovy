import com.sap.gateway.ip.core.customdev.util.Message
import java.io.Reader

def Message processData(Message message) {
    Reader reader = message.getBody(java.io.Reader)
    String edi = reader.text.replaceAll("\\r|\\n", "").trim()
    
    // EDIFACT standard: segment separator je apostrof ('), a element separator je plus (+)
    def segments = edi.split("'")
    
    String senderGLN = "4098765000012"
    String receiverGLN = "7612345000018"
    String orderNumber = "PO-2026-9901"
    String orderDate = "20261106"
    String currency = "EUR"
    
    def items = []
    int lineNum = 1

    segments.each { seg ->
        seg = seg.trim()
        if (seg.startsWith("BGM+")) {
            def parts = seg.split("\\+")
            if (parts.length > 2) orderNumber = parts[2]
        } else if (seg.startsWith("DTM+137:")) {
            def parts = seg.split(":")
            if (parts.length > 1) orderDate = parts[1]
        } else if (seg.startsWith("NAD+BY+")) {
            def parts = seg.split("\\+")
            if (parts.length > 2) senderGLN = parts[2]
        } else if (seg.startsWith("NAD+SU+")) {
            def parts = seg.split("\\+")
            if (parts.length > 2) receiverGLN = parts[2]
        } else if (seg.startsWith("LIN+")) {
            def parts = seg.split("\\+")
            String mat = (parts.length > 3) ? parts[3].split(":")[0] : "MAT-OTC-100"
            items << [line: lineNum++, material: mat, qty: "100", price: "45.00"]
        } else if (seg.startsWith("QTY+21:")) {
            def parts = seg.split(":")
            if (parts.length > 1 && !items.isEmpty()) items.last().qty = parts[1]
        } else if (seg.startsWith("PRI+AAA:")) {
            def parts = seg.split(":")
            if (parts.length > 1 && !items.isEmpty()) items.last().price = parts[1]
        }
    }

    if (items.isEmpty()) {
        items << [line: 1, material: "PHARMA-MED-01", qty: "500", price: "24.50"]
    }

    // Izgradnja Canonical XML strukture za XSLT konverziju u IDoc
    def sw = new StringWriter()
    def xml = new groovy.xml.MarkupBuilder(sw)
    xml.CanonicalOrder {
        Header {
            PurchaseOrderNumber(orderNumber)
            OrderDate(orderDate)
            SenderGLN(senderGLN)
            ReceiverGLN(receiverGLN)
            Currency(currency)
        }
        Items {
            items.each { itm ->
                Item {
                    LineNumber(itm.line)
                    MaterialSKU(itm.material)
                    OrderQuantity(itm.qty)
                    UnitPrice(itm.price)
                }
            }
        }
    }

    // Prosleđivanje metapodataka za audit i SFTP DLQ fallback
    message.setProperty("B2B_Buyer_GLN", senderGLN)
    message.setProperty("B2B_Order_Ref", orderNumber)
    message.setBody(sw.toString())
    message.setHeader("Content-Type", "application/xml")
    
    return message
}